"""Rebuild exact grayscale experiment sample lists using original RGB pixels."""
import concurrent.futures,hashlib,io,json,shutil,threading,time,traceback,zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
import yaml
GRAY=Path('/data/wujiasheng/football_gray_ab_20261004')
ROOT=Path('/data/wujiasheng/football_rgb_ab_20261004');ROOT.mkdir(exist_ok=True)
(ROOT/'audit').mkdir(exist_ok=True)
_tls=threading.local()
def convert(r):
 if not hasattr(_tls,'archives'):_tls.archives={}
 if r['archive'] not in _tls.archives:_tls.archives[r['archive']]=zipfile.ZipFile(r['archive'])
 with Image.open(io.BytesIO(_tls.archives[r['archive']].read(r['member']))) as im:
  rgb=im.convert('RGB');assert rgb.size==(r['width'],r['height'])
  gray=rgb.convert('L');digest=hashlib.sha256(str(gray.size).encode()+gray.tobytes()).hexdigest()
  assert digest==r['gray_sha256'],r['member']
  out=ROOT/'data'/r['domain']/'images'/Path(r['image']).name
  rgb.save(out,compress_level=1)
 label=ROOT/'data'/r['domain']/'labels'/Path(r['label']).name
 shutil.copyfile(r['label'],label)
 r=dict(r,gray_reference_image=r['image'],gray_reference_label=r['label'],image=str(out),label=str(label),color_mode='RGB')
 return r

def prepare(domain):
 source=GRAY/'data'/domain
 records=json.loads((source/'manifest.json').read_text());target=ROOT/'data'/domain
 for sub in ['images','labels']:(target/sub).mkdir(parents=True,exist_ok=True)
 converted=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
  for i,r in enumerate(pool.map(convert,records),1):
   converted.append(r)
   if i%1000==0:print(domain,'RGB converted',i,'/',len(records),flush=True)
 assert [(r['member'],r['split'],r['boxes']) for r in records]==[(r['member'],r['split'],r['boxes']) for r in converted]
 for split in sorted({r['split'] for r in converted}):
  rs=[r for r in converted if r['split']==split]
  (target/f'{split}.txt').write_text(''.join(r['image']+'\n' for r in rs))
  old=(source/f'{split}.txt').read_text().splitlines()
  assert [Path(p).name for p in old]==[Path(r['image']).name for r in rs]
  positives=[r for r in rs if r['boxes']]
  import random
  sample=random.Random(42).sample(positives,min(12,len(positives)))
  canvas=Image.new('RGB',(1280,780),'#202020');draw=ImageDraw.Draw(canvas)
  for k,r in enumerate(sample):
   with Image.open(r['image']) as src:
    assert src.mode=='RGB'
    im=src.copy();d=ImageDraw.Draw(im)
    for b in r['boxes']:d.rectangle(b['xyxy'],outline='red',width=max(2,im.width//250))
    im.thumbnail((320,235));x,y=k%4*320,k//4*260;canvas.paste(im,(x,y));draw.text((x+4,y+237),r['name'][:40],fill='white')
  canvas.save(ROOT/'audit'/f'{domain}_{split}_samples.jpg',quality=88)
 config=yaml.safe_load((source/'dataset.yaml').read_text());config['path']=str(target)
 (target/'dataset.yaml').write_text(yaml.safe_dump(config))
 (target/'manifest.json').write_text(json.dumps(converted,indent=2,ensure_ascii=False))
 shutil.copyfile(source/'summary.json',target/'summary.json')
 (target/'READY').write_text(time.strftime('%Y-%m-%d %H:%M:%S'))
 print(domain,'READY',len(converted),'all grayscale hashes, sample order, splits and labels match',flush=True)

if __name__=='__main__':
 try:
  assert (GRAY/'DATA_READY').exists()
  # Upper bound: raw uncompressed RGB pixels plus 25%, with 20 GiB reserve.
  manifests=[json.loads((GRAY/'data'/d/'manifest.json').read_text()) for d in ['real','sim']]
  needed=sum(r['width']*r['height']*3 for rs in manifests for r in rs)*1.25+20*1024**3
  assert shutil.disk_usage(ROOT).free>needed,'Insufficient space for lossless RGB data'
  prepare('real');prepare('sim')
  (ROOT/'DATA_READY').write_text('All original RGB pixels and labels paired with grayscale experiment.\n')
 except Exception:
  (ROOT/'PREPARE_FAILED').write_text(traceback.format_exc());raise
