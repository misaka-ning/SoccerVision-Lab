"""Fixed-budget YOLO11n ball detection control experiment; no segmentation."""
import argparse,csv,json,os,subprocess,time,traceback,hashlib
from pathlib import Path
ROOT=Path('/data/wujiasheng/football_gray_ab_20261004')
def write_json(path,data):
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False));tmp.replace(path)
def status(arm,phase,**kw):
 write_json(ROOT/f'status_{arm}.json',dict(arm=arm,phase=phase,updated=time.strftime('%Y-%m-%d %H:%M:%S'),**kw))
def await_data(domain,arm):
 p=ROOT/'data'/domain/'READY'
 while not p.exists():
  status(arm,'waiting_for_'+domain+'_data')
  if (ROOT/'PREPARE_FAILED').exists():raise RuntimeError('Data preparation failed; see prepare.log')
  time.sleep(15)
def await_gpu(gpu,arm):
 for _ in range(480):
  row=subprocess.check_output(['nvidia-smi',f'--id={gpu}','--query-gpu=memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip()
  mem,util=map(int,row.split(','))
  if mem<512 and util<10:return
  status(arm,'waiting_for_gpu',gpu=gpu,memory_used_MiB=mem,utilization=util);time.sleep(15)
 raise RuntimeError('Selected GPU remained occupied for 2h')
def train(arm,stage,weights,domain,epochs):
 from ultralytics import YOLO
 from ultralytics.nn.modules import Segment
 status(arm,stage,epochs=epochs,domain=domain)
 model=YOLO(str(weights),task='detect')
 assert model.task=='detect' and not any(isinstance(m,Segment) for m in model.model.modules())
 model.train(data=str(ROOT/'data'/domain/'dataset.yaml'),epochs=epochs,imgsz=640,batch=32,device=0,
  workers=4,seed=42,deterministic=True,optimizer='AdamW',lr0=.001,lrf=.01,weight_decay=.0005,
  momentum=.9,warmup_epochs=3,cos_lr=True,patience=0,amp=False,cache=False,
  hsv_h=0.,hsv_s=0.,hsv_v=.25,degrees=5.,translate=.1,scale=.5,shear=0.,perspective=0.,
  flipud=0.,fliplr=.5,mosaic=1.,mixup=0.,copy_paste=0.,close_mosaic=10,
  project=str(ROOT/'runs'),name=stage,exist_ok=False,plots=True,save=True,save_period=-1,
  single_cls=True,classes=[0],resume=False,pretrained=True,verbose=False)
 best=ROOT/'runs'/stage/'weights'/'best.pt'
 assert best.exists()
 return best

def iou(a,b):
 x1=max(a[0],b[0]);y1=max(a[1],b[1]);x2=min(a[2],b[2]);y2=min(a[3],b[3])
 inter=max(0,x2-x1)*max(0,y2-y1);union=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
 return inter/union if union>0 else 0.
def evaluate(arm,best):
 from ultralytics import YOLO
 status(arm,'evaluating_real_test',weights=str(best))
 model=YOLO(str(best));assert model.model.model[-1].nc==1
 metrics=model.val(data=str(ROOT/'data/real/dataset.yaml'),split='test',imgsz=640,batch=32,device=0,workers=4,
  conf=.001,iou=.7,max_det=300,plots=True,save_txt=True,save_conf=True,
  project=str(ROOT/'evaluations'),name=arm+'_real_test',exist_ok=False,verbose=False)
 manifest=json.loads((ROOT/'data/real/manifest.json').read_text());rows=[]
 for r in manifest:
  if r['split']!='test':continue
  label=ROOT/'evaluations'/f'{arm}_real_test'/'labels'/(Path(r['image']).stem+'.txt');pred=[]
  if label.exists():
   for line in label.read_text().splitlines():
    c,x,y,w,h,conf=map(float,line.split())
    if conf<.25:continue
    assert c==0
    iw,ih=r['width'],r['height'];pred.append((conf,[(x-w/2)*iw,(y-h/2)*ih,(x+w/2)*iw,(y+h/2)*ih]))
  matched=set();fp=0;gt=r['boxes']
  for conf,box in sorted(pred,key=lambda t:t[0],reverse=True):
   candidates=[(iou(box,b['xyxy']),j) for j,b in enumerate(gt) if j not in matched]
   score,j=max(candidates,default=(0,-1))
   if score>=.5:matched.add(j)
   else:fp+=1
  small={j for j,b in enumerate(gt) if (b['xyxy'][2]-b['xyxy'][0])*(b['xyxy'][3]-b['xyxy'][1])*(640/max(r['width'],r['height']))**2<32**2}
  blur={j for j,b in enumerate(gt) if b['blurred']};occ={j for j,b in enumerate(gt) if b['concealed']}
  rows.append(dict(image=r['name'],group=r['split_group'],gt=len(gt),tp=len(matched),fp=fp,fn=len(gt)-len(matched),
    small_gt=len(small),small_tp=len(small&matched),blurred_gt=len(blur),blurred_tp=len(blur&matched),
    concealed_gt=len(occ),concealed_tp=len(occ&matched),negative=int(not gt),negative_fp_image=int(not gt and fp>0)))
 totals={k:sum(r[k] for r in rows) for k in rows[0] if k not in ['image','group']}
 def ratio(a,b):return a/b if b else None
 fixed=dict(confidence=.25,matching_iou=.5,precision=ratio(totals['tp'],totals['tp']+totals['fp']),recall=ratio(totals['tp'],totals['gt']),
  small_ball_recall=ratio(totals['small_tp'],totals['small_gt']),blurred_ball_recall=ratio(totals['blurred_tp'],totals['blurred_gt']),
  concealed_ball_recall=ratio(totals['concealed_tp'],totals['concealed_gt']),negative_image_false_positive_rate=ratio(totals['negative_fp_image'],totals['negative']),
  false_positives_per_image=totals['fp']/len(rows),counts=totals)
 out=dict(arm=arm,weights=str(best),test_images=len(rows),ultralytics_metrics={k:float(v) for k,v in metrics.results_dict.items()},
   fixed_threshold=fixed,speed_ms=metrics.speed)
 write_json(ROOT/f'results_{arm}.json',out)
 with (ROOT/f'per_image_{arm}.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 status(arm,'complete',results=str(ROOT/f'results_{arm}.json'))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['A','B'],required=True);p.add_argument('--gpu',type=int,required=True);a=p.parse_args()
 os.environ['CUDA_VISIBLE_DEVICES']=str(a.gpu);os.environ['OMP_NUM_THREADS']='4';os.environ['MKL_NUM_THREADS']='4';os.environ['YOLO_AUTOINSTALL']='false'
 os.chdir(ROOT)
 try:
  await_data('real',a.arm)
  if a.arm=='B':await_data('sim',a.arm)
  await_gpu(a.gpu,a.arm)
  baseline=ROOT/'weights/yolo11n.pt'
  assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1'
  if a.arm=='A':best=train('A','A_real_only',baseline,'real',50)
  else:
   pre=train('B','B_sim_pretrain',baseline,'sim',30)
   best=train('B','B_real_finetune',pre,'real',50)
  evaluate(a.arm,best)
 except Exception as e:
  status(a.arm,'failed',error=repr(e));traceback.print_exc();raise
