"""Use the exact frozen A/B trainer for RGB C/D; wait for exclusive GPUs."""
import argparse,hashlib,importlib.util,json,os,time,traceback
from pathlib import Path
GRAY=Path('/data/wujiasheng/football_gray_ab_20261004')
ROOT=Path('/data/wujiasheng/football_rgb_ab_20261004')
spec=importlib.util.spec_from_file_location('paired_trainer',ROOT/'paired_trainer.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core);core.ROOT=ROOT
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['C','D'],required=True);p.add_argument('--gpu',type=int,required=True);a=p.parse_args()
 os.environ['CUDA_VISIBLE_DEVICES']=str(a.gpu);os.environ['OMP_NUM_THREADS']='4';os.environ['MKL_NUM_THREADS']='4';os.environ['YOLO_AUTOINSTALL']='false'
 os.chdir(ROOT)
 try:
  core.await_data('real',a.arm)
  if a.arm=='D':core.await_data('sim',a.arm)
  predecessor='A' if a.arm=='C' else 'B'
  while True:
   p=GRAY/f'status_{predecessor}.json';state=json.loads(p.read_text()) if p.exists() else {}
   if state.get('phase') in ['complete','failed']:break
   core.status(a.arm,'queued_after_'+predecessor,gpu=a.gpu,predecessor_phase=state.get('phase'));time.sleep(20)
  core.await_gpu(a.gpu,a.arm)
  baseline=ROOT/'weights/yolo11n.pt'
  assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='0ebbc80d4a7680d14987a577cd21342b65ecfd94632bd9a8da63ae6417644ee1'
  if a.arm=='C':best=core.train('C','C_rgb_real_only',baseline,'real',50)
  else:
   pre=core.train('D','D_rgb_sim_pretrain',baseline,'sim',30)
   best=core.train('D','D_rgb_real_finetune',pre,'real',50)
  core.evaluate(a.arm,best)
 except Exception as e:
  core.status(a.arm,'failed',error=repr(e));traceback.print_exc();raise
