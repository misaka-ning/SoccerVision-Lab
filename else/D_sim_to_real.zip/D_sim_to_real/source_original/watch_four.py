import csv,json,os,time
from pathlib import Path
GRAY=Path('/data/wujiasheng/football_gray_ab_20261004')
ROOT=Path('/data/wujiasheng/football_rgb_ab_20261004')
ROOTS={'A':GRAY,'B':GRAY,'C':ROOT,'D':ROOT}
def save(p,obj):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False));tmp.replace(p)
while True:
 states={a:json.loads((r/f'status_{a}.json').read_text()) if (r/f'status_{a}.json').exists() else {'phase':'starting'} for a,r in ROOTS.items()}
 pidpath=ROOT/'pids.json'
 if pidpath.exists():
  pids=json.loads(pidpath.read_text())
  for task,pid in pids.items():
   if task not in ['C','D','prepare']:continue
   if task=='prepare':
    if (ROOT/'DATA_READY').exists() or (ROOT/'PREPARE_FAILED').exists():continue
   elif states[task]['phase'] in ['complete','failed']:continue
   try:
    proc=Path(f'/proc/{pid}/stat').read_text();alive=proc.split(') ',1)[1].split()[0]!='Z'
   except FileNotFoundError:alive=False
   if not alive:
    if task=='prepare':(ROOT/'PREPARE_FAILED').write_text('RGB preparation exited without DATA_READY; inspect prepare.log')
    else:
     states[task]={'arm':task,'phase':'failed','error':'Process exited without completion; inspect arm log'}
     save(ROOT/f'status_{task}.json',states[task])
 all_done=all(s.get('phase')=='complete' for s in states.values())
 save(ROOT/'four_arm_status.json',dict(phase='complete' if all_done else 'running_with_failure' if any(s.get('phase')=='failed' for s in states.values()) else 'running',arms=states,rgb_preparation='complete' if (ROOT/'DATA_READY').exists() else 'failed' if (ROOT/'PREPARE_FAILED').exists() else 'running',updated=time.strftime('%Y-%m-%d %H:%M:%S')))
 if all_done:break
 if all(s.get('phase') in ['failed','complete'] for s in states.values()):raise RuntimeError('At least one arm failed; no complete four-way comparison')
 time.sleep(30)
results={a:json.loads((r/f'results_{a}.json').read_text()) for a,r in ROOTS.items()}
metrics={}
for key in ['metrics/mAP50(B)','metrics/mAP50-95(B)']:
 metrics[key]={a:v['ultralytics_metrics'][key] for a,v in results.items()}
for key in ['precision','recall','small_ball_recall','blurred_ball_recall','concealed_ball_recall','negative_image_false_positive_rate','false_positives_per_image']:
 metrics[key]={a:v['fixed_threshold'][key] for a,v in results.items()}
rows=[]
for metric,v in metrics.items():
 row=dict(metric=metric,**v)
 for name,x,y in [('sim_gain_gray','B','A'),('sim_gain_rgb','D','C'),('rgb_gain_real_only','C','A'),('rgb_gain_sim_then_real','D','B')]:
  row[name]=v[x]-v[y] if v[x] is not None and v[y] is not None else None
 rows.append(row)
limitations=['One seed (42) per arm; preliminary comparison.',
 'B/D have 30 additional synthetic pretraining epochs; compute is not matched to A/C.',
 'All arms share exact sample IDs, boxes and split order; A/B use grayscale and C/D use original RGB at both training and evaluation.',
 'Hue and saturation augmentation remain disabled in all arms to isolate input color.',
 'Filename prefix group split reduces source-sequence leakage but does not guarantee unseen venue or camera.',
 'Small ball is an image-size proxy (area below 32x32 after long-side scaling to 640), not measured distance.',
 'Fixed metrics use confidence 0.25, matching IoU 0.5; lower false positive metrics are better.']
save(ROOT/'comparison_four.json',dict(arms=results,comparison=rows,limitations=limitations))
with (ROOT/'comparison_four.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['YOLO11n ball-only: grayscale/RGB x real-only/simulation-then-real',
 'A=gray real50; B=gray sim30+real50; C=RGB real50; D=RGB sim30+real50','',
 'metric | A | B | C | D']
for r in rows:lines.append(' | '.join(str(r[k]) for k in ['metric','A','B','C','D']))
lines+=['','Limitations:']+limitations
(ROOT/'comparison_four.txt').write_text('\n'.join(lines)+'\n')
print('FOUR_ARM_COMPARISON_COMPLETE',flush=True)
