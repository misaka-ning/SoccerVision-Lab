# D 组：原版 YOLO11n RGB 足球检测

仿真 RGB 预训练 30 轮，再真实 RGB 微调 50 轮。仅 Detect 检测头，类别 0=ball（足球），没有分割头。

## 内容

- weights/best.pt：真实数据训练/微调完成后的最终最佳权重，用于推理。
- weights/yolo11n_initial.pt：原版初始化权重。
- predict.py：保留原始 RGB 信息的图片/目录推理入口，默认使用包内示例。
- model/yolo11.yaml：原版网络结构；算子实现由 ultralytics 8.4.95 提供。
- source_original/：服务器实际执行的训练、数据准备、汇总脚本，原样保留。
- records/：训练参数、曲线、测试指标、依赖记录、逐张样本清单和数据划分。
- samples/demo_rgb.png：与灰度包演示相同帧的原始彩色测试图。

D 组另含 weights/sim_pretrain_best.pt；这是仿真阶段权重，不是最终推理权重。

## 本机运行

```bash
cd /home/sunteng/codes/YOLO_RGB
./.venv/bin/python D_sim_to_real/predict.py --device 0
./.venv/bin/python D_sim_to_real/predict.py --source /绝对路径/图片或目录 --output ./predictions_D --device 0 --conf 0.25
```

无 GPU 时使用 --device cpu。默认输出为本组 predictions/，包含检测框图片和 JSON 坐标。
脚本通过 Pillow 读取 RGB，然后转为 Ultralytics NumPy 输入约定的 BGR；框架内部会转换回 RGB。没有灰度转换，也没有复制灰度通道。
训练中的 single_cls=True 将权重内类别显示名记为 item；脚本仅在运行时将类别 0 显示为 ball，不修改原始权重。

## 环境与复现

当前电脑 .venv 复用原 rfdetr_yolo 项目依赖。新机器可创建虚拟环境后 pip install -r requirements.txt，按硬件安装兼容的 PyTorch。
服务器训练环境完整版本记录见 records/environment.freeze.txt。
原始训练代码保留服务器 ROOT、GPU、队列依赖和数据压缩包路径，本地重训前需要调整。paired_trainer.py 是实际训练与评估实现，train_rgb.py 是 C/D 队列及阶段入口。
包内不含完整训练图像或服务器环境。records/data 保存本实验的样本、框及划分；重训应复用同一划分，不能把测试图混入训练。
