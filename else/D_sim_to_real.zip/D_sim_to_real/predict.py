"""YOLO11n ball-only inference using original RGB content (no grayscale conversion)."""
from pathlib import Path
import argparse,json
import numpy as np
from PIL import Image
from ultralytics import YOLO
from ultralytics.nn.modules import Segment
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--source',type=Path,default=ROOT/'samples/demo_rgb.png',help='Image or directory of images')
 p.add_argument('--weights',type=Path,default=ROOT/'weights/best.pt')
 p.add_argument('--output',type=Path,default=ROOT/'predictions')
 p.add_argument('--device',default='cpu',help='cpu, or GPU index such as 0')
 p.add_argument('--conf',type=float,default=.25)
 p.add_argument('--imgsz',type=int,default=640)
 a=p.parse_args()
 source=a.source.resolve()
 if not source.exists():p.error(f'Source does not exist: {source}')
 files=sorted(f for f in source.rglob('*') if f.suffix.lower() in {'.jpg','.jpeg','.png','.bmp','.tif','.tiff','.webp'}) if source.is_dir() else [source]
 if not files:p.error('No input images found')
 model=YOLO(str(a.weights),task='detect')
 assert model.task=='detect' and model.model.model[-1].nc==1 and set(model.names)=={0},model.names
 assert model.names[0] in {'ball','item'},model.names
 # single_cls=True stores the generic name 'item'; class 0 is ball in the dataset.
 model.model.names={0:'ball'}
 assert not any(isinstance(m,Segment) for m in model.model.modules())
 a.output.mkdir(parents=True,exist_ok=True)
 summaries=[]
 for f in files:
  with Image.open(f) as im:
   # Ultralytics numpy inputs are BGR; its loader converts them to RGB.
   image=np.asarray(im.convert('RGB'))[:,:,::-1].copy()
  result=model.predict(image,imgsz=a.imgsz,conf=a.conf,iou=.7,max_det=300,device=a.device,verbose=False)[0]
  relative=f.relative_to(source) if source.is_dir() else Path(f.name)
  out=a.output/relative.parent/(relative.name+'.pred.jpg');out.parent.mkdir(parents=True,exist_ok=True)
  result.save(filename=str(out))
  detections=[{'class_id':int(c),'label':'ball','confidence':float(conf),'xyxy':[float(v) for v in box]} for box,conf,c in zip(result.boxes.xyxy.cpu().tolist(),result.boxes.conf.cpu().tolist(),result.boxes.cls.cpu().tolist())]
  entry={'source':str(f),'prediction_image':str(out),'detections':detections}
  (out.with_suffix('.json')).write_text(json.dumps(entry,ensure_ascii=False,indent=2))
  summaries.append(entry)
 (a.output/'predictions.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2))
 print(json.dumps({'images':len(files),'detections':sum(len(r['detections']) for r in summaries),'output':str(a.output.resolve()),'model_names':model.names},ensure_ascii=False))
if __name__=='__main__':main()
