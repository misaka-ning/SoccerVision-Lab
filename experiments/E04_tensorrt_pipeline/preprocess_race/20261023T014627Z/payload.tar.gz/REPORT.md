# MAXN 预处理快速赛马

日期：2026-10-23。状态：只读实机检查和隔离候选开发完成，离线正确性/性能采集待运行；当前没有本轮实测加速结论。

## 已确认

机器人 Orin NX，现有 MAXN（mode0），GPU动态范围306～918MHz。未修改功耗、时钟或其他后台进程。查询nvpmodel时EMC sysfs部分权限不足，模式/MAXN与GPU上限独立可读。用户报告当前约23Hz，本轮尚未复测；E03/E04在25W/408MHz测得的数据不能替代当前MAXN基线。

E01 Engine SHA256：98c1b6bc703b29874d95db94d9cf51ef5b4a4142a7ca6cf22362a0c616fbf348。当前源/安装版A2、Graph、预测器及配置一致；640、batch2、class0、conf0.45、top-k5、原NMS及定位保持。发布上限50Hz，Viser/点云关闭。

真实顺序：OpenCV INTER_LINEAR resize→114 constant padding→np.stack→BGR/RGB与CHW视图→ascontiguousarray→from_numpy→阻塞to(device)→FP32→除255。每次resize与padding都有新输出，stack和最终连续batch也反复分配；数值转换和传输仍是必要成本。E04旧C2只省pack约0.3～0.4ms，MAXN下Resize/Padding占比须由本轮诊断数据确认。

## 本轮仅两个正式筛选候选

| 候选 | 改动 | 回退 |
|---|---|---|
| R0 | 现有MAXN+A2+Graph | 原实现 |
| canvas | 左右目独立缓存Letterbox Canvas，resize直接写ROI，后续原预处理不变 | handle.restore() |
| reuse | 复用现成Canvas+RGB/CHW host打包，保留阻塞传输与每次独立FP32输出 | handle.restore() |

候选仅挂到本实验拥有的predictor实例，不写正式部署代码或YAML。每次模型load完成后才挂接，避免640启动黑图冻结原图shape；保持原Graph缓冲区/流和A2实现不变。

既有Torch bilinear只有旧数值探针，约10.59%通道像素差1uint8，未把它当成等价的可部署GPU候选。本次没有从零开发CUDA模块。VPI2.4.8已可import；离线脚本只在独立子进程对CUDA/VIC直接BGR8缩放作一次资格探测，记录支持/像素差异/同步完成墙钟；未通过或需要复杂NV12互操作则不进入候选。单图probe不是完整系统加速证据。

## 验证与唯一筛选入口

复用E04已冻结61对真实Val（含已知Small、Occluded、Blurred、No Ball标签和左右目不对称），逐图SHA校验；不访问Test。两候选本地CPU与实际机器人LetterBox源码输入逐值相等，9项CPU测试通过；本地整合后的20项候选/真实下游fake/筛选决策测试全部通过，VPI probe也已完成Python3.8语法和CPU/mock检查。GPU输入、raw、所有框、候选、左右目匹配、定位/跟踪/ROS语义仍必须通过实机同Engine对照。

每候选100次真实输入预热，正式400次。一次离线筛选分4小块交错 R0/候选/候选/R0（中间顺序反转），每块每候选100次；R0共800次，不做完整系统多轮筛选。计时包含Resize/Padding/打包/实际传输/FP32/归一化至输入就绪，保存mean/P95/P99及逐帧CSV。记录CPU提交墙钟、同步完成墙钟和CUDA事件跨度；事件跨度含CPU提交间隙，不称作纯kernel耗时。每次计时之后在范围外执行原Graph推理并同步，保持代表性活动GPU负载。

诊断另保留50次CPU分段方法墙钟，Resize/Padding嵌套在pre_transform中，不能重复相加，也不将异步方法墙钟当GPU kernel时间。遥测保存sysfs频率/温度与tegrastats功耗原文。

门槛：正确性exact；双目对均值节省至少1ms；4块均有收益，最大基线首尾漂移小于收益；每块P95/P99不退化。没有候选满足则按用户要求结束Resize/Letterbox研究，保持R0。候选通过后先回收审查，才安排唯一一次3组交错R0/R1系统A/B（100预热、每次60秒），不在当前脚本自动开相机或发布消息。系统测试使用独立ROS Domain87/localhost，必须由用户确认现场安全、固定相机及球在双目视野。

若当前确为23Hz（约43.48ms/cycle），达到25Hz理想上需节省约3.48ms/cycle；1ms仅是继续实机验证的门槛，不代表25Hz达成。

## 结果与保留结论

正确性、短时mean/P95/P99、正式系统对照、是否25Hz、是否保留：均待实机采集，禁止用本地CPU或历史25W数据填充。

重要原始数据集中在一个offline attempt：environment.json、correctness.json、per_pair.json、diagnostic.json、screen_frames.csv、summary.json、telemetry.jsonl、tegrastats.log、status.json。source快照和frozen.json给出代码/配置/Engine身份。没有复制模型或重复大图数据；图片引用既有冻结Val。

回滚：候选为本进程私有hook，退出restore后恢复；生产部署未修改，无需修改生产配置。构建脚本不捕获Graph。长脚本交用户运行，不需要Codex持续监视。

机器人屏蔽GPU预检已通过：66份生产源/安装代码与配置一致，61对/122张Val哈希通过；已知标签覆盖Small28、Occluded27、Blurred22、No Ball22张（多标签，不相加为总数）。离线入口已放在独立results目录，尚未启动。
