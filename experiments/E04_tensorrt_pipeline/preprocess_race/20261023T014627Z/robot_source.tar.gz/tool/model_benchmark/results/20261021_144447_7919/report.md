# 模型性能测试

状态：complete

Engine 为 ms/batch；只汇总完整轮次。变化率仅在双方完成所有计划轮次后提供。
系统延迟是“读取完成到发布调用返回”，不包含相机曝光/缓存或下游接收。
系统 Hz 包含 ROS、Viser 和调度等待；不能用 1000/Engine耗时代替。

| 模型 | 模式 | 完成轮数 | 样本 | 耗时均值 ms | P95 ms | 处理 Hz | 发布 Hz |
|---|---|---:|---:|---:|---:|---:|---:|
| E1 | engine | 3 | 6157 | 28.181 | 28.255 | - | - |
| E2 | engine | 3 | 6136 | 28.279 | 28.356 | - | - |
| E1 | system | 3 | 2970 | 49.299 | 51.923 | 16.490 | 16.489 |
| E2 | system | 3 | 2963 | 49.448 | 52.090 | 16.450 | 16.450 |

## 相对基线 E1

- E1 / engine：engine_ms_saved=0.000, engine_ms_reduction_percent=0.000
- E2 / engine：engine_ms_saved=-0.098, engine_ms_reduction_percent=-0.348
- E1 / system：read_ready_to_publish_ms_saved=0.000, read_ready_to_publish_ms_reduction_percent=0.000, processing_hz_gain_percent=0.000
- E2 / system：read_ready_to_publish_ms_saved=-0.149, read_ready_to_publish_ms_reduction_percent=-0.303, processing_hz_gain_percent=-0.238

各轮数据见 summary.json；配置见 config_resolved.yaml；逐帧数据和工作进程日志在各轮目录。
系统默认 ROS_DOMAIN_ID=87；Viser 客户端连接数、场景和背景负载应保持一致。
