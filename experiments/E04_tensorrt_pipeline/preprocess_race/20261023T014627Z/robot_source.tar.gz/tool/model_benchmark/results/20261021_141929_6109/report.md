# 模型性能测试

状态：failed

Engine 为 ms/batch；只汇总完整轮次。变化率仅在双方完成所有计划轮次后提供。
系统延迟是“读取完成到发布调用返回”，不包含相机曝光/缓存或下游接收。
系统 Hz 包含 ROS、Viser 和调度等待；不能用 1000/Engine耗时代替。

| 模型 | 模式 | 完成轮数 | 样本 | 耗时均值 ms | P95 ms | 处理 Hz | 发布 Hz |
|---|---|---:|---:|---:|---:|---:|---:|
| E1 | engine | 1 | 171 | 28.185 | 28.221 | - | - |
| E2 | engine | 1 | 171 | 28.271 | 28.305 | - | - |

## 相对基线 E1

- E1 / engine：engine_ms_saved=0.000, engine_ms_reduction_percent=0.000
- E2 / engine：engine_ms_saved=-0.086, engine_ms_reduction_percent=-0.304

各轮数据见 summary.json；配置见 config_resolved.yaml；逐帧数据和工作进程日志在各轮目录。
系统默认 ROS_DOMAIN_ID=87；Viser 客户端连接数、场景和背景负载应保持一致。
